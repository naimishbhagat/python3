print("Ecommcerce Initialised")
